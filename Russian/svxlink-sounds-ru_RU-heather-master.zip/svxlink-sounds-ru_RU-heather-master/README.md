# svxlink-sounds-ru_RU-heather
Russian Language Pack for SvxLink Server

Русский языковой пакет для сервера SVXLINK
==========================================

Звуковые файлы сгенерированы посредством голосового ассистента Милана из операционной системы Mac OS X. 

Порядок и логика произношения фраз изменена в соответствии с правилами русского языка.

В файле https://github.com/circool/svxlink-sounds-ru_RU-heather/blob/master/TODO.md изложен план действий.

В файле https://github.com/circool/svxlink-sounds-ru_RU-heather/blob/master/INSTALL.md описан процесс установки.

Дополнение
----------

По умолчанию будет использоваться 24-часовой формат времени.
