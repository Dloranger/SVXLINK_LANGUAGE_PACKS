# Процедура установки

1. Установите пакет SVXLINK (например из оригинального репозитория https://github.com/sm0svx/svxlink)
2. Поместите папку ru_RU в каталог /usr/share/svxlink/sound/
3. Задайте параметр **DEFAULT_LANG=ru_RU** в разделе указанном в параметре **LOGICS** раздела **[GLOBAL]**
