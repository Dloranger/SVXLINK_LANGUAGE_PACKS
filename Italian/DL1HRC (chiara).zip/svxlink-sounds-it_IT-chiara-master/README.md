Italian Voice "Chiara" for SvxLink
Created with acapella group (https://www.acapela-group.com/)
Free to use for SvxLink users, no Copyright

Adi / DL1HRC
