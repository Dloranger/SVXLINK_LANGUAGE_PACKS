Swedish Language Pack for SvxLink Server
========================================
This is a swedish language pack for [SvxLink Server](http://www.svxlink.org/)
created using the Elin voice from the
[Acapela Box](https://www.acapela-box.com/) service.

These are raw files which cannot be used directly with SvxLink Server. They
must first be processed using the filter_sounds.sh script to get the correct
format.

Download processed sound files from the [releases
page](https://github.com/sm0svx/svxlink-sounds-sv_SE-elin/releases).
