# fr_FR_Agnes
Vous trouverez tous les sons avec la voie d'Agnès pour SVXLink.
Cette voix est celle qui est la plus complète car je fais mes tests avec celle ci.
Elle comprend tous les sons compatible avec la SVXLink Card avec un repertoire dedié. 

[Le site de la Carte SVXCard](http://svxcard.f5uii.net/)
# fr_FR_Agnes
