English Language Pack for SvxLink Server
========================================
This is an english language pack for [SvxLink Server](http://www.svxlink.org/)
created using the Hazel voice from the Microsoft stable.
That are not sold nor should they be offered for sale
